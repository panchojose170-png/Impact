package com.impactframes;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Ajustes del mod. Se guardan en config/impactframes.properties */
public final class ImpactConfig {
    /** Probabilidad (0 a 100) de que salga el efecto en un golpe valido. */
    public static volatile int chance = 35;

    private ImpactConfig() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("impactframes.properties");
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }

    public static void load() {
        try {
            Path p = file();
            if (Files.exists(p)) {
                Properties props = new Properties();
                try (InputStream in = Files.newInputStream(p)) {
                    props.load(in);
                }
                chance = clamp(Integer.parseInt(props.getProperty("chance", "35").trim()));
            } else {
                save();
            }
        } catch (Exception e) {
            ImpactFrames.LOGGER.warn("No se pudo leer la configuracion de Impact Frames, uso los valores por defecto", e);
        }
    }

    public static void save() {
        try {
            Path p = file();
            Files.createDirectories(p.getParent());
            Properties props = new Properties();
            props.setProperty("chance", Integer.toString(clamp(chance)));
            try (OutputStream out = Files.newOutputStream(p)) {
                props.store(out, "Impact Frames - chance = probabilidad del efecto en porcentaje (0 a 100)");
            }
        } catch (Exception e) {
            ImpactFrames.LOGGER.warn("No se pudo guardar la configuracion de Impact Frames", e);
        }
    }
}
