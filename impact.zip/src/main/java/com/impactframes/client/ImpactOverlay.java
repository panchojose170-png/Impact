package com.impactframes.client;

import com.impactframes.ImpactPayload;
import net.minecraft.client.Minecraft;

import java.util.Random;

/**
 * Dibuja los impact frames encima del HUD. Todo se arma con rectangulos (fill), asi que no
 * necesita texturas y se ve pixelado como el resto de Minecraft.
 */
public final class ImpactOverlay {
    /** Dibuja un rectangulo relleno (x1,y1 incluido; x2,y2 excluido) con color ARGB. */
    public interface Sink {
        void rect(int x1, int y1, int x2, int y2, int argb);
    }

    private static final int BLACK = 0xFF000000;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int ORANGE = 0xFFFF9A2E;
    private static final int PALE = 0xFFFFF4C2;

    private static final Random RANDOM = new Random();

    private static long startMs = -1;
    private static long durationMs = 0;
    private static int kind = 0;
    private static int tool = 0;
    private static double flip = 1.0;
    private static double baseAngle = 0.0;
    private static int rays = 16;
    private static double[] angles = new double[32];
    private static double[] lengths = new double[32];
    private static double[] widths = new double[32];

    private ImpactOverlay() {
    }

    /** Arranca un impact frame nuevo (reemplaza al que estuviera en pantalla). */
    public static void trigger(int code) {
        kind = code / 10;
        tool = code % 10;
        startMs = System.currentTimeMillis();
        flip = RANDOM.nextBoolean() ? 1.0 : -1.0;
        baseAngle = RANDOM.nextDouble() * Math.PI;
        rays = 14 + RANDOM.nextInt(5);
        for (int i = 0; i < rays; i++) {
            angles[i] = baseAngle + i * (2 * Math.PI / rays) + (RANDOM.nextDouble() - 0.5) * 0.25;
            lengths[i] = 14 + RANDOM.nextDouble() * 22;
            widths[i] = 1.2 + RANDOM.nextDouble() * 1.8;
        }
        if (kind == ImpactPayload.KIND_SLASH) {
            durationMs = 300;
        } else if (kind == ImpactPayload.KIND_CRIT) {
            durationMs = 430;
        } else {
            durationMs = 400;
        }
    }

    /** Se llama en cada frame; dibuja si hay un efecto activo. */
    public static void draw(Sink s) {
        if (startMs < 0) {
            return;
        }
        long elapsed = System.currentTimeMillis() - startMs;
        if (elapsed >= durationMs) {
            startMs = -1;
            return;
        }
        double p = elapsed / (double) durationMs;

        Minecraft mc = Minecraft.getInstance();
        drawFrame(s, mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight(), p);
    }

    /** Dibuja el efecto en el punto p (0 a 1) de su duracion, para una pantalla de w x h. */
    static void drawFrame(Sink s, int w, int h, double p) {
        double cx = w / 2.0;
        double cy = h / 2.0;
        double u = Math.min(w, h) / 240.0;

        if (kind == ImpactPayload.KIND_SLASH) {
            drawSlash(s, w, h, cx, cy, u, p);
        } else if (kind == ImpactPayload.KIND_CRIT) {
            drawCrit(s, w, h, cx, cy, u, p);
        } else {
            drawStar(s, w, h, cx, cy, u, p);
        }
    }

    // ------------------------------------------------------------------ cortes

    private static void drawSlash(Sink s, int w, int h, double cx, double cy, double u, double p) {
        u = u * 1.25;
        flash(s, w, h, p, 0.18, 30);

        double x0, y0, x1, y1, maxW;
        if (tool == ImpactPayload.TOOL_AXE) {
            // hachazo: mas corto, grueso y casi vertical
            x0 = cx + 20 * u * flip;
            y0 = cy - 46 * u;
            x1 = cx - 14 * u * flip;
            y1 = cy + 30 * u;
            maxW = 6.5 * u;
        } else {
            // espada: corte diagonal largo y fino
            x0 = cx + 46 * u * flip;
            y0 = cy - 30 * u;
            x1 = cx - 46 * u * flip;
            y1 = cy + 30 * u;
            maxW = 3.6 * u;
        }

        double reveal = ease(p / 0.30);
        double tailFrom = easeIn((p - 0.35) / 0.65);

        stroke(s, x0, y0, x1, y1, maxW + 3, 0, tailFrom, reveal, BLACK);
        stroke(s, x0, y0, x1, y1, maxW, 0, tailFrom, reveal, WHITE);

        // segunda linea fina paralela (el "eco" del corte)
        double dx = x1 - x0;
        double dy = y1 - y0;
        double len = Math.sqrt(dx * dx + dy * dy);
        double nx = -dy / len * 7 * u;
        double ny = dx / len * 7 * u;
        double reveal2 = ease((p - 0.06) / 0.30);
        stroke(s, x0 + nx, y0 + ny, x1 + nx, y1 + ny, 1.7 * u + 2, 0, tailFrom, reveal2, BLACK);
        stroke(s, x0 + nx, y0 + ny, x1 + nx, y1 + ny, 1.7 * u, 0, tailFrom, reveal2, WHITE);
    }

    // ---------------------------------------------------------------- criticos

    private static void drawCrit(Sink s, int w, int h, double cx, double cy, double u, double p) {
        u = u * 1.15;
        flash(s, w, h, p, 0.20, 75);

        double x0, y0, x1, y1, maxW;
        int shape;
        double burstScale;
        if (tool == ImpactPayload.TOOL_AXE) {
            // hachazo hacia abajo: ancho y pesado
            x0 = cx + 5 * u * flip;
            y0 = cy - 62 * u;
            x1 = cx - 2 * u * flip;
            y1 = cy + 20 * u;
            maxW = 11 * u;
            shape = 0;
            burstScale = 0.9;
        } else if (tool == ImpactPayload.TOOL_PICKAXE) {
            // picotazo: punta que se clava en el centro
            x0 = cx;
            y0 = cy - 58 * u;
            x1 = cx;
            y1 = cy + 6 * u;
            maxW = 9 * u;
            shape = 1;
            burstScale = 0.7;
        } else {
            // espada: tajo largo y fino hacia abajo
            x0 = cx + 14 * u * flip;
            y0 = cy - 70 * u;
            x1 = cx - 6 * u * flip;
            y1 = cy + 52 * u;
            maxW = 5.4 * u;
            shape = 0;
            burstScale = 1.0;
        }

        double reveal = ease(p / 0.22);
        double tailFrom = easeIn((p - 0.30) / 0.70);

        stroke(s, x0, y0, x1, y1, maxW + 3.5, shape, tailFrom, reveal, BLACK);
        stroke(s, x0, y0, x1, y1, maxW, shape, tailFrom, reveal, PALE);
        stroke(s, x0, y0, x1, y1, maxW * 0.38, shape, tailFrom, reveal, WHITE);

        if (p > 0.16) {
            double grow = ease((p - 0.16) / 0.24);
            double fade = clamp01((p - 0.42) / 0.58);
            burst(s, x1, y1, u, grow, fade, 3, burstScale, ORANGE, WHITE);

            if (tool == ImpactPayload.TOOL_AXE) {
                // astillas que salen disparadas
                for (int i = 0; i < 6; i++) {
                    double a = angles[i] + 0.3;
                    double d = (10 + lengths[i]) * u * grow;
                    int px = (int) Math.round(x1 + Math.cos(a) * d);
                    int py = (int) Math.round(y1 + Math.sin(a) * d);
                    int size = (int) Math.max(2, Math.round(3 * u * (1 - fade)));
                    s.rect(px - 1, py - 1, px + size + 1, py + size + 1, BLACK);
                    s.rect(px, py, px + size, py + size, WHITE);
                }
            }
        }
    }

    // ----------------------------------------------------------------- estrella

    private static void drawStar(Sink s, int w, int h, double cx, double cy, double u, double p) {
        u = u * 1.25;
        flash(s, w, h, p, 0.22, 85);

        double grow = ease(p / 0.26);
        double shrink = 1 - Math.pow(clamp01((p - 0.55) / 0.45), 2);
        double sc = grow * shrink;
        if (sc <= 0.02) {
            return;
        }

        // lineas de velocidad negras y naranjas alrededor, como un estallido
        for (int i = 0; i < rays; i++) {
            double a = angles[i];
            double r0 = (24 + (i % 3) * 4) * u * sc;
            double r1 = r0 + (14 + lengths[i]) * u * sc;
            double wd = widths[i] * u * 0.9;
            int color = (i % 2 == 0) ? ORANGE : BLACK;
            stroke(s, cx + Math.cos(a) * r0, cy + Math.sin(a) * r0,
                    cx + Math.cos(a) * r1, cy + Math.sin(a) * r1, wd + 1.5, 1, 0, 1, BLACK);
            stroke(s, cx + Math.cos(a) * r0, cy + Math.sin(a) * r0,
                    cx + Math.cos(a) * r1, cy + Math.sin(a) * r1, wd, 1, 0, 1, color);
        }

        // contorno negro de la estrella
        starShape(s, cx, cy, u, sc, 3.5, BLACK);
        // estrella blanca
        starShape(s, cx, cy, u, sc, 0, WHITE);
    }

    /** Estrella de 8 puntas: 4 largas (en cruz) y 4 cortas (en diagonal) mas un disco al centro. */
    private static void starShape(Sink s, double cx, double cy, double u, double sc, double extra, int color) {
        for (int i = 0; i < 8; i++) {
            double a = baseAngle + i * (Math.PI / 4);
            boolean longRay = (i % 2 == 0);
            double len = (longRay ? 36 : 22) * u * sc;
            double wd = (longRay ? 8 : 5) * u * sc + extra;
            stroke(s, cx - Math.cos(a) * len, cy - Math.sin(a) * len,
                    cx + Math.cos(a) * len, cy + Math.sin(a) * len, wd, 0, 0, 1, color);
        }
        disc(s, cx, cy, (int) Math.round(7 * u * sc + extra * 0.6), color);
    }

    // ------------------------------------------------------------------ ayudas

    private static void burst(Sink s, double cx, double cy, double u, double grow, double fade,
                              double r0u, double lenScale, int colorA, int colorB) {
        for (int i = 0; i < rays; i++) {
            double a = angles[i];
            double r0 = r0u * u + 6 * u * grow;
            double r1 = r0 + lengths[i] * u * lenScale * grow * (1 - fade);
            if (r1 <= r0 + 1) {
                continue;
            }
            double wd = widths[i] * u * (1 - fade * 0.8);
            double ax = cx + Math.cos(a) * r0;
            double ay = cy + Math.sin(a) * r0;
            double bx = cx + Math.cos(a) * r1;
            double by = cy + Math.sin(a) * r1;
            stroke(s, ax, ay, bx, by, wd + 2, 1, 0, 1, BLACK);
            stroke(s, ax, ay, bx, by, wd, 1, 0, 1, (i % 3 == 0) ? colorA : colorB);
        }
    }

    /** Destello suave de pantalla completa al inicio del efecto. */
    private static void flash(Sink s, int w, int h, double p, double until, int maxAlpha) {
        if (p >= until) {
            return;
        }
        int a = (int) (maxAlpha * (1 - p / until));
        if (a > 0) {
            s.rect(0, 0, w, h, (a << 24) | 0x00FFFFFF);
        }
    }

    /**
     * Trazo grueso hecho de cuadritos. shape: 0 = lente (fino en las puntas), 1 = se afina hacia el
     * final, 2 = ancho parejo. from/to = parte visible del trazo (0 a 1).
     */
    private static void stroke(Sink s, double x0, double y0, double x1, double y1,
                               double maxW, int shape, double from, double to, int color) {
        if (to <= from) {
            return;
        }
        double dx = x1 - x0;
        double dy = y1 - y0;
        double len = Math.sqrt(dx * dx + dy * dy);
        int n = (int) Math.max(2, Math.min(600, len));
        int i0 = (int) Math.floor(from * n);
        int i1 = (int) Math.ceil(to * n);
        for (int i = i0; i <= i1; i++) {
            double t = i / (double) n;
            double wd;
            if (shape == 0) {
                // el trazo visible siempre termina en punta, tambien cuando se esta borrando
                double tv = (t - from) / (to - from);
                wd = maxW * Math.sin(Math.PI * clamp01(tv));
            } else if (shape == 1) {
                wd = maxW * (1 - t);
            } else {
                wd = maxW;
            }
            int size = (int) Math.max(1, Math.round(wd));
            int px = (int) Math.round(x0 + dx * t) - size / 2;
            int py = (int) Math.round(y0 + dy * t) - size / 2;
            s.rect(px, py, px + size, py + size, color);
        }
    }

    private static void disc(Sink s, double cx, double cy, int r, int color) {
        if (r < 1) {
            return;
        }
        int x = (int) Math.round(cx);
        int y = (int) Math.round(cy);
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy));
            s.rect(x - hw, y + dy, x + hw + 1, y + dy + 1, color);
        }
    }

    private static double clamp01(double t) {
        return t < 0 ? 0 : (t > 1 ? 1 : t);
    }

    private static double ease(double t) {
        double c = clamp01(t);
        return 1 - Math.pow(1 - c, 3);
    }

    private static double easeIn(double t) {
        double c = clamp01(t);
        return c * c;
    }
}
