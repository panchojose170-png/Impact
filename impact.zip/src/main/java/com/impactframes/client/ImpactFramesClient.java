package com.impactframes.client;

import com.impactframes.ImpactFrames;
import com.impactframes.ImpactPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.resources.Identifier;

public class ImpactFramesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Cuando el servidor avisa que hubo un golpe con efecto, se arranca la animacion
        ClientPlayNetworking.registerGlobalReceiver(ImpactPayload.TYPE,
                (payload, context) -> context.client().execute(() -> ImpactOverlay.trigger(payload.code())));

        // Se dibuja encima de todo el HUD. El tipo del primer parametro se deja sin nombrar a proposito.
        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(ImpactFrames.MOD_ID, "overlay"),
                (graphics, tickCounter) -> ImpactOverlay.draw(
                        (x1, y1, x2, y2, argb) -> graphics.fill(x1, y1, x2, y2, argb)));
    }
}
