package com.impactframes.client;

import com.impactframes.ImpactConfig;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Pantalla de ajustes que se abre desde Mod Menu. */
public class ImpactConfigScreen extends Screen {
    private final Screen parent;

    public ImpactConfigScreen(Screen parent) {
        super(Component.literal("Impact Frames"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = this.height / 2 - 50;

        StringWidget title = new StringWidget(cx - 150, top, 300, 20,
                Component.literal("Impact Frames"), this.font);
        title.alignCenter();
        this.addRenderableWidget(title);

        StringWidget hint = new StringWidget(cx - 150, top + 22, 300, 20,
                Component.literal("Probabilidad de que salga el efecto en cada golpe"), this.font);
        hint.alignCenter();
        this.addRenderableWidget(hint);

        this.addRenderableWidget(new ChanceSlider(cx - 100, top + 48, 200, 20));

        this.addRenderableWidget(Button.builder(Component.literal("Listo"), button -> this.onClose())
                .bounds(cx - 100, top + 78, 200, 20)
                .build());
    }

    @Override
    public void onClose() {
        ImpactConfig.save();
        this.minecraft.setScreen(this.parent);
    }

    private static class ChanceSlider extends AbstractSliderButton {
        ChanceSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Component.empty(), ImpactConfig.chance / 100.0);
            this.updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Component.literal("Probabilidad: " + Math.round(this.value * 100) + "%"));
        }

        @Override
        protected void applyValue() {
            ImpactConfig.chance = (int) Math.round(this.value * 100);
        }
    }
}
