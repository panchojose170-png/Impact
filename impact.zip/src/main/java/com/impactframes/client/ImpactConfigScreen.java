package com.impactframes.client;

import com.impactframes.ImpactConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Pantalla de ajustes que se abre desde Mod Menu. */
public class ImpactConfigScreen extends Screen {
    private final Screen parent;

    public ImpactConfigScreen(Screen parent) {
        super(Component.literal("Impact Frames"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = this.height / 2 - 50;

        StringWidget title = new StringWidget(cx - 150, top, 300, 20,
                Component.literal("Impact Frames"), this.font);
        this.addRenderableWidget(title);

        StringWidget hint = new StringWidget(cx - 150, top + 22, 300, 20,
                Component.literal("Probabilidad de que salga el efecto en cada golpe"), this.font);
        this.addRenderableWidget(hint);

        this.addRenderableWidget(new ChanceSlider(cx - 100, top + 48, 200, 20));

        this.addRenderableWidget(Button.builder(Component.literal("Listo"), button -> this.onClose())
                .bounds(cx - 100, top + 78, 200, 20)
                .build());
    }

    @Override
    public void onClose() {
        ImpactConfig.save();
        openScreen(this.parent);
    }

    /**
     * Abre otra pantalla. Minecraft.setScreen cambio de lugar en 26.x, asi que se busca el metodo
     * (en Minecraft o en el objeto que lo trae ahora) en vez de llamarlo directo.
     */
    private void openScreen(Screen target) {
        Minecraft mc = this.minecraft;
        if (mc == null) {
            return;
        }
        if (callSetScreen(mc, target)) {
            return;
        }
        for (Field f : Minecraft.class.getDeclaredFields()) {
            if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) {
                continue;
            }
            try {
                f.setAccessible(true);
                Object holder = f.get(mc);
                if (holder != null && callSetScreen(holder, target)) {
                    return;
                }
            } catch (ReflectiveOperationException | RuntimeException ignored) {
                // sigue con el siguiente campo
            }
        }
        // Ultimo recurso: cerrar esta pantalla (vuelve al juego)
        super.onClose();
    }

    private static boolean callSetScreen(Object holder, Screen target) {
        for (Class<?> c = holder.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (m.getName().equals("setScreen") && m.getParameterCount() == 1
                        && m.getParameterTypes()[0].isAssignableFrom(Screen.class)) {
                    try {
                        m.setAccessible(true);
                        m.invoke(holder, target);
                        return true;
                    } catch (ReflectiveOperationException | RuntimeException ignored) {
                        return false;
                    }
                }
            }
        }
        return false;
    }

    private static class ChanceSlider extends AbstractSliderButton {
        ChanceSlider(int x, int y, int width, int height) {
            super(x, y, width, height, Component.empty(), ImpactConfig.chance / 100.0);
            this.updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Component.literal("Probabilidad: " + Math.round(this.value * 100) + "%"));
        }

        @Override
        protected void applyValue() {
            ImpactConfig.chance = (int) Math.round(this.value * 100);
        }
    }
}
