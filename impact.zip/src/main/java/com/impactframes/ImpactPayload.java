package com.impactframes;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/**
 * Paquete servidor -> cliente que le dice al jugador que dibuje un impact frame.
 * code = tipo * 10 + herramienta
 */
public record ImpactPayload(int code) implements CustomPacketPayload {
    /** Golpe normal con espada o hacha: corte. */
    public static final int KIND_SLASH = 0;
    /** Golpe critico: golpe hacia abajo adaptado a la herramienta. */
    public static final int KIND_CRIT = 1;
    /** Flecha que acierta: estrella en el centro de la pantalla. */
    public static final int KIND_STAR = 2;

    public static final int TOOL_SWORD = 0;
    public static final int TOOL_AXE = 1;
    public static final int TOOL_PICKAXE = 2;

    public static final CustomPacketPayload.Type<ImpactPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(ImpactFrames.MOD_ID, "impact"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ImpactPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, ImpactPayload::code, ImpactPayload::new);

    public static int make(int kind, int tool) {
        return kind * 10 + tool;
    }

    public int kind() {
        return code / 10;
    }

    public int tool() {
        return code % 10;
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
