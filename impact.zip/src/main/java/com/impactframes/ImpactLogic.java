package com.impactframes;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/** Logica del servidor: decide cuando sale el efecto, aplica el dano extra y avisa al jugador. */
public final class ImpactLogic {
    /** Ultimo ataque cuerpo a cuerpo de cada jugador: a quien golpeo y si fue critico. */
    private record Pending(UUID target, boolean crit) {
    }

    private static final Map<UUID, Pending> PENDING = new ConcurrentHashMap<>();

    /** Evita que el golpe extra vuelva a disparar el efecto. */
    private static boolean applyingExtra = false;

    private ImpactLogic() {
    }

    public static void register() {
        // Se ejecuta justo antes de que el jugador ataque: aqui el estado todavia es el original
        // (en el aire, sin correr...) y se puede saber si el golpe sera critico.
        AttackEntityCallback.EVENT.register((player, level, hand, target, hitResult) -> {
            if (player instanceof ServerPlayer sp) {
                PENDING.put(sp.getUUID(), new Pending(target.getUUID(), isCrit(sp, target)));
            }
            return InteractionResult.PASS;
        });

        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damage, blocked) -> {
            if (applyingExtra || blocked || damage <= 0.0F) {
                return;
            }
            if (!(source.getEntity() instanceof ServerPlayer player)) {
                return;
            }
            if (!(entity.level() instanceof ServerLevel serverLevel)) {
                return;
            }

            Entity direct = source.getDirectEntity();
            int kind;
            int tool = ImpactPayload.TOOL_SWORD;

            if (direct == player) {
                // Golpe cuerpo a cuerpo
                Pending pending = PENDING.get(player.getUUID());
                if (pending == null || !pending.target().equals(entity.getUUID())) {
                    return;
                }
                ItemStack held = player.getMainHandItem();
                boolean sword = held.is(ItemTags.SWORDS);
                boolean axe = held.is(ItemTags.AXES);
                boolean pick = held.is(ItemTags.PICKAXES);
                if (!sword && !axe && !pick) {
                    return;
                }
                tool = sword ? ImpactPayload.TOOL_SWORD : (axe ? ImpactPayload.TOOL_AXE : ImpactPayload.TOOL_PICKAXE);
                if (pending.crit()) {
                    kind = ImpactPayload.KIND_CRIT;
                } else if (pick) {
                    // El pico en golpe normal no hace nada
                    return;
                } else {
                    kind = ImpactPayload.KIND_SLASH;
                }
            } else if (isArrow(direct)) {
                // Flecha que acierta
                kind = ImpactPayload.KIND_STAR;
            } else {
                return;
            }

            // Probabilidad ajustable
            if (ThreadLocalRandom.current().nextInt(100) >= ImpactConfig.chance) {
                return;
            }

            // Dano extra: como un segundo golpe con la mitad del dano del primero (x1.5 en total)
            if (entity.isAlive()) {
                applyingExtra = true;
                try {
                    resetInvulnerability(entity);
                    entity.hurtServer(serverLevel, source, baseDamage * 0.5F);
                } finally {
                    applyingExtra = false;
                }
            }

            // Impact frame solo para quien golpea
            ImpactPayload payload = new ImpactPayload(ImpactPayload.make(kind, tool));
            if (ServerPlayNetworking.canSend(player, ImpactPayload.TYPE)) {
                ServerPlayNetworking.send(player, payload);
            }

            // Sonido para todos los que esten cerca
            SoundEvent sound = kind == ImpactPayload.KIND_STAR
                    ? ImpactSounds.STAR
                    : (kind == ImpactPayload.KIND_CRIT ? ImpactSounds.CRIT : ImpactSounds.SLASH);
            float pitch = 0.92F + ThreadLocalRandom.current().nextFloat() * 0.16F;
            serverLevel.playSound(null, entity.getX(), entity.getY(), entity.getZ(),
                    sound, SoundSource.PLAYERS, 1.0F, pitch);
        });
    }

    /** Mismas condiciones que usa Minecraft para un golpe critico cuerpo a cuerpo. */
    private static boolean isCrit(ServerPlayer p, Entity target) {
        return target instanceof LivingEntity
                && p.getAttackStrengthScale(0.5F) > 0.9F
                && p.fallDistance > 0
                && !p.onGround()
                && !p.onClimbable()
                && !p.isInWater()
                && !p.isPassenger()
                && !p.isSprinting();
    }

    /** Flecha normal o espectral (se reconoce por el nombre de la clase, que no cambia entre versiones). */
    private static boolean isArrow(Entity e) {
        return e != null && e.getClass().getSimpleName().contains("Arrow");
    }

    private static Field invulnerableField;
    private static boolean invulnerableLookedUp = false;

    /** invulnerableTime ahora es privado en Entity; se pone en 0 por reflexion para que el 2do golpe entre. */
    private static void resetInvulnerability(Entity e) {
        if (!invulnerableLookedUp) {
            invulnerableLookedUp = true;
            try {
                Field f = Entity.class.getDeclaredField("invulnerableTime");
                f.setAccessible(true);
                invulnerableField = f;
            } catch (ReflectiveOperationException | RuntimeException ex) {
                ImpactFrames.LOGGER.warn("No pude acceder a invulnerableTime; el dano extra puede no aplicarse", ex);
            }
        }
        if (invulnerableField != null) {
            try {
                invulnerableField.setInt(e, 0);
            } catch (ReflectiveOperationException | RuntimeException ex) {
                invulnerableField = null;
            }
        }
    }
}
