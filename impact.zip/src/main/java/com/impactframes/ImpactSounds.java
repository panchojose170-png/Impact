package com.impactframes;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Sonidos propios del mod (los .ogg estan en assets/impactframes/sounds). */
public final class ImpactSounds {
    public static final SoundEvent SLASH = register("slash");
    public static final SoundEvent CRIT = register("crit");
    public static final SoundEvent STAR = register("star");

    private ImpactSounds() {
    }

    private static SoundEvent register(String name) {
        Identifier id = Identifier.fromNamespaceAndPath(ImpactFrames.MOD_ID, name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    /** Fuerza la carga de la clase para que se registren los sonidos. */
    public static void init() {
    }
}
