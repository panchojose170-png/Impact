package com.impactframes;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImpactFrames implements ModInitializer {
    public static final String MOD_ID = "impactframes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ImpactConfig.load();
        ImpactSounds.init();
        registerPayload();
        ImpactLogic.register();
        LOGGER.info("Impact Frames cargado (probabilidad {}%)", ImpactConfig.chance);
    }

    /**
     * Registra el paquete servidor -> cliente. En Fabric API para 26.x el metodo ya no se llama
     * playS2C() (ahora es clientboundPlay()), asi que se busca por nombre y funciona con los dos.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void registerPayload() {
        Object registry = null;
        for (Method m : PayloadTypeRegistry.class.getMethods()) {
            String n = m.getName().toLowerCase();
            if (Modifier.isStatic(m.getModifiers())
                    && m.getParameterCount() == 0
                    && PayloadTypeRegistry.class.isAssignableFrom(m.getReturnType())
                    && n.contains("play")
                    && (n.contains("s2c") || n.contains("clientbound"))) {
                try {
                    registry = m.invoke(null);
                    break;
                } catch (ReflectiveOperationException e) {
                    LOGGER.warn("No se pudo usar PayloadTypeRegistry.{}", m.getName(), e);
                }
            }
        }
        if (registry == null) {
            throw new IllegalStateException("Impact Frames: no encontre como registrar el paquete servidor->cliente");
        }
        ((PayloadTypeRegistry) registry).register(ImpactPayload.TYPE, ImpactPayload.CODEC);
    }
}
