package com.impactframes;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ImpactFrames implements ModInitializer {
    public static final String MOD_ID = "impactframes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ImpactConfig.load();
        ImpactSounds.init();
        PayloadTypeRegistry.playS2C().register(ImpactPayload.TYPE, ImpactPayload.CODEC);
        ImpactLogic.register();
        LOGGER.info("Impact Frames cargado (probabilidad {}%)", ImpactConfig.chance);
    }
}
